Example showing how to expand GameActivity bridge files.

You can find the source code in https://github.com/todi1856/AndroidExamples.